import { initSpatialScene } from './spatial-scene.js';
import { startRegistration, startAuthentication, browserSupportsWebAuthn } from '@simplewebauthn/browser';

const $ = (id) => document.getElementById(id);
const status = $('auth-status');
let busy = false;
let currentUser = null;
let authGeneration = 0;
initSpatialScene();

function showStatus(message, error = false) {
  status.textContent = message;
  status.dataset.error = String(error);
}
function setBusy(value) {
  if (value) authGeneration += 1;
  busy = value;
  document.body.dataset.busy = String(value);
  document.querySelectorAll('.vault-panel button, .vault-panel input').forEach((el) => { el.disabled = value; });
  $('auth-panel').setAttribute('aria-busy', String(value));
  $('account-panel').setAttribute('aria-busy', String(value));
  if (!browserSupportsWebAuthn()) {
    $('login-form').querySelector('button').disabled = true;
    $('register-form').querySelector('button').disabled = true;
  }
}
function showTab(register) {
  if (busy) return;
  $('register-form').hidden = !register;
  $('login-form').hidden = register;
  $('register-tab').setAttribute('aria-selected', String(register));
  $('login-tab').setAttribute('aria-selected', String(!register));
  showStatus('');
}
$('login-tab').addEventListener('click', () => showTab(false));
$('register-tab').addEventListener('click', () => showTab(true));
for (const id of ['login-tab', 'register-tab']) {
  $(id).addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      const register = $('register-tab').getAttribute('aria-selected') !== 'true';
      showTab(register); $(register ? 'register-tab' : 'login-tab').focus();
    }
  });
}
function clearPrivate() {
  authGeneration += 1;
  currentUser = null;
  $('private-items').replaceChildren();
  $('key-list').replaceChildren();
  $('account-name').textContent = '';
  $('key-evidence').textContent = '';
  $('key-evidence').hidden = true;
  $('key-evidence-open').setAttribute('aria-expanded', 'false');
  $('account-panel').hidden = true;
  $('auth-panel').hidden = false;
  $('add-key-form').hidden = true;
}
async function api(path, method = 'GET', body) {
  const response = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401) clearPrivate();
    throw new Error(data.message || `요청을 처리하지 못했습니다. (${response.status})`);
  }
  return data;
}
function renderItems(items) {
  const fragment = document.createDocumentFragment();
  for (const item of items) {
    const article = document.createElement('article'); article.className = 'private-item';
    const heading = document.createElement('h4'); heading.textContent = item.title;
    const text = document.createElement('p'); text.textContent = item.content;
    article.append(heading, text); fragment.append(article);
  }
  $('private-items').replaceChildren(fragment);
}
function renderKeys(keys) {
  const fragment = document.createDocumentFragment();
  for (const key of keys) {
    const row = document.createElement('li');
    const info = document.createElement('div');
    const name = document.createElement('strong'); name.textContent = key.name;
    const detail = document.createElement('small');
    const date = new Date(key.createdAt);
    detail.textContent = `등록 ${Number.isNaN(date.getTime()) ? '날짜 확인 불가' : date.toLocaleString('ko-KR', {timeZone: 'Asia/Seoul'})}`;
    info.append(name, detail);
    const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '삭제';
    remove.setAttribute('aria-label', `${key.name} 패스키 삭제`);
    remove.addEventListener('click', () => deleteKey(key, keys.length));
    row.append(info, remove); fragment.append(row);
  }
  $('key-list').replaceChildren(fragment);
}
async function loadAccount(user) {
  const generation = authGeneration;
  const [vault, keys] = await Promise.all([api('/api/vault'), api('/api/passkeys')]);
  if (generation !== authGeneration) return;
  currentUser = user || vault.user;
  $('account-name').textContent = currentUser.username;
  renderItems(vault.items || []); renderKeys(keys.passkeys || []);
  $('auth-panel').hidden = true;
  $('account-panel').hidden = false;
}
function authError(error) {
  const cancelled = ['NotAllowedError', 'AbortError'].includes(error.name) || /ceremony.*cancelled/i.test(error.message);
  return cancelled ? '패스키 요청을 취소했거나 시간이 지났습니다. 저장하지 않았으니 다시 시도해 주세요.' : (error.message || '요청을 처리하지 못했습니다. 다시 시도해 주세요.');
}
async function registerPasskey(username, name, adding = false) {
  let completed = false;
  try {
    const data = await api('/api/passkeys/register/options', 'POST', { username, name, ...(adding ? { mode: 'add' } : {}) });
    const response = await startRegistration({ optionsJSON: data.options });
    const result = await api('/api/passkeys/register/verify', 'POST', response);
    completed = true;
    await loadAccount(result.user);
    showStatus('패스키가 등록되었습니다. 나만의 공간을 열었습니다.');
  } finally {
    if (!completed) await api('/api/passkeys/register/cancel', 'POST', {}).catch(() => {});
  }
}
$('register-form').addEventListener('submit', async (event) => {
  event.preventDefault(); if (busy) return;
  const username = $('username').value.trim();
  const name = $('credential-name').value.trim();
  if (!name) { showStatus('패스키 이름을 입력해 주세요.', true); return; }
  setBusy(true); showStatus('기기의 패스키 등록 창에서 요청을 확인해 주세요.');
  try { await registerPasskey(username, name); } catch (error) { showStatus(authError(error), true); } finally { setBusy(false); }
});
$('login-form').addEventListener('submit', async (event) => {
  event.preventDefault(); if (busy) return;
  setBusy(true); showStatus('기기에서 등록한 패스키를 선택해 주세요.');
  try {
    const data = await api('/api/passkeys/authenticate/options', 'POST', {});
    const response = await startAuthentication({ optionsJSON: data.options });
    const result = await api('/api/passkeys/authenticate/verify', 'POST', response);
    await loadAccount(result.user); showStatus('본인 확인이 완료되었습니다.');
  } catch (error) { showStatus(authError(error), true); } finally { setBusy(false); }
});
$('logout').addEventListener('click', async () => {
  if (busy) return; setBusy(true);
  try { await api('/api/logout', 'POST', {}); clearPrivate(); showStatus('로그아웃했습니다. 나만의 공간을 닫았습니다.'); }
  catch (error) { showStatus(error.message, true); } finally { setBusy(false); }
});
$('add-key-open').addEventListener('click', () => { if (busy) return; showStatus('새 패스키 이름을 입력한 뒤 등록해 주세요.'); $('add-key-form').hidden = false; $('new-key-name').focus(); });
$('add-key-close').addEventListener('click', () => { $('add-key-form').hidden = true; $('new-key-name').value = ''; $('add-key-open').focus(); });
$('add-key-form').addEventListener('submit', async (event) => {
  event.preventDefault(); if (busy || !currentUser) return;
  const name = $('new-key-name').value.trim();
  if (!name) { showStatus('새 패스키 이름을 입력해 주세요.', true); return; }
  const username = currentUser.username;
  setBusy(true); showStatus('기기에서 새 패스키 등록을 승인해 주세요.');
  try { await registerPasskey(username, name, true); $('add-key-form').hidden = true; $('new-key-name').value = ''; }
  catch (error) { showStatus(authError(error), true); } finally { setBusy(false); }
});
async function deleteKey(key, total) {
  if (busy) return;
  const warning = total === 1
    ? `마지막 패스키 “${key.name}”를 삭제하면 즉시 로그아웃되며, 이 계정의 자료에 다시 접근할 수 없습니다. 비밀번호 복구 기능도 없습니다. 정말 삭제하시겠습니까?`
    : `패스키 “${key.name}”를 삭제하시겠습니까? 삭제한 패스키로는 다시 로그인할 수 없습니다. 남아 있는 다른 패스키를 보관했는지 확인해 주세요.`;
  if (!window.confirm(warning)) return;
  setBusy(true); showStatus('패스키를 삭제하고 있습니다.');
  try {
    const result = await api(`/api/passkeys/${encodeURIComponent(key.id)}`, 'DELETE', {confirm: true});
    if (result.loggedOut) { clearPrivate(); showStatus('패스키가 삭제되어 로그아웃했습니다. 남은 패스키가 있다면 그 패스키로 로그인하세요.'); }
    else { await loadAccount(currentUser); showStatus('선택한 패스키를 삭제했습니다.'); }
  } catch (error) { showStatus(error.message, true); } finally { setBusy(false); }
}
if (!browserSupportsWebAuthn()) {
  $('support-note').hidden = false;
  $('login-form').querySelector('button').disabled = true;
  $('register-form').querySelector('button').disabled = true;
}
async function refreshSession() {
  const generation = authGeneration;
  try {
    const session = await api('/api/session');
    if (generation !== authGeneration || busy) return;
    if (session.authenticated) await loadAccount(session.user);
    else if (currentUser) { clearPrivate(); showStatus('로그인이 만료되었습니다. 패스키로 다시 로그인해 주세요.'); }
  } catch (error) { showStatus(error.message, true); }
}
refreshSession();
document.addEventListener('visibilitychange', () => { if (!document.hidden && !busy) refreshSession(); });
setInterval(() => { if (!document.hidden && !busy) refreshSession(); }, 60000);

// Real local browser-only measurements; no synthetic visitor totals or server reporting.
const labels = {home:'홈',about:'소개',strengths:'강점',experience:'경험',likes:'취향',projects:'프로젝트','project-portal':'프로젝트',private:'나만의 공간',visitor:'방문 기록'};
let localDB;
let metrics;
function renderMetrics() {
  $('visit-count').textContent = String(metrics.visits);
  $('click-count').textContent = String(metrics.clicks);
  const top = Object.entries(metrics.sections).sort((a,b) => b[1]-a[1])[0];
  $('top-interest').textContent = top ? labels[top[0]] || top[0] : '아직 없음';
}
function saveMetrics() {
  if (!localDB || !metrics) return;
  const tx = localDB.transaction('metrics', 'readwrite'); tx.objectStore('metrics').put(metrics, 'summary');
  renderMetrics();
}
try {
  const request = indexedDB.open('hope-personal-space', 1);
  request.onupgradeneeded = () => { request.result.createObjectStore('metrics'); };
  request.onerror = () => { for (const id of ['visit-count','click-count','top-interest']) $(id).textContent = '저장 불가'; };
  request.onsuccess = () => {
    localDB = request.result;
    const read = localDB.transaction('metrics').objectStore('metrics').get('summary');
    read.onsuccess = () => { metrics = read.result || {visits:0, clicks:0, sections:{}}; metrics.visits += 1; saveMetrics(); };
    read.onerror = () => { for (const id of ['visit-count','click-count','top-interest']) $(id).textContent = '저장 불가'; };
  };
} catch { for (const id of ['visit-count','click-count','top-interest']) $(id).textContent = '저장 불가'; }
document.querySelectorAll('a[href^="#"]').forEach((link) => link.addEventListener('click', () => {
  if (!metrics) return;
  const target = link.getAttribute('href').slice(1);
  if (!labels[target]) return;
  metrics.clicks += 1; metrics.sections[target] = (metrics.sections[target] || 0) + 1; saveMetrics();
}));

for (const [id,target] of Object.entries({'enter-screen':'projects','desktop-projects-tab':'projects','desktop-about-tab':'about','desktop-experience-tab':'experience','desktop-likes-tab':'likes'})) {
  $(id).addEventListener('click',()=>{if(!metrics)return;metrics.clicks+=1;metrics.sections[target]=(metrics.sections[target]||0)+1;saveMetrics();});
}

// Native dialogs keep focus inside the detail view and support Escape to close.
const projectDialog = $('project-detail-dialog');
document.querySelectorAll('.project-detail-button').forEach(button => {
  button.addEventListener('click', () => {
    const card = button.closest('.portal-card');
    $('project-detail-title').textContent = card.querySelector('h4').textContent;
    $('project-detail-description').textContent = card.querySelector('p').textContent;
    projectDialog.showModal();
    if (metrics) { metrics.clicks += 1; metrics.sections.projects = (metrics.sections.projects || 0) + 1; saveMetrics(); }
  });
});
projectDialog.addEventListener('click', event => {
  if (event.target !== projectDialog) return;
  const r = projectDialog.getBoundingClientRect();
  if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) projectDialog.close();
});

$('key-evidence-open').addEventListener('click', async () => {
  if (!currentUser || busy) return;
  const panel = $('key-evidence');
  if (!panel.hidden) { panel.hidden = true; $('key-evidence-open').setAttribute('aria-expanded', 'false'); return; }
  const generation = authGeneration;
  try {
    const evidence = await api('/api/passkeys/evidence');
    if (generation !== authGeneration || !currentUser) return;
    panel.textContent = JSON.stringify({format:evidence.keyFormat,passkeys:evidence.passkeys}, null, 2);
    panel.hidden = false; $('key-evidence-open').setAttribute('aria-expanded', 'true');
  } catch (error) { if (generation === authGeneration) showStatus(error.message, true); }
});
