// Byte-range responses let media decoders seek without re-fetching the whole video.
export function serveAsset(request,item,baseHeaders={}) {
 const bytes=Uint8Array.from(atob(item.data),c=>c.charCodeAt(0));
 const headers=new Headers({...baseHeaders,'Content-Type':item.type,'Accept-Ranges':'bytes'});
 let status=200,body=bytes;
 const range=request.headers.get('Range');
 if(range&&request.method==='GET') {
  const match=/^bytes=(\d*)-(\d*)$/.exec(range);
  let start=0,end=bytes.length-1;
  let valid=!!match&&(match[1]!==''||match[2]!=='');
  if(valid) {
   if(match[1]===''){const suffix=Number(match[2]);valid=Number.isSafeInteger(suffix)&&suffix>0;start=Math.max(0,bytes.length-suffix);}
   else {start=Number(match[1]);if(match[2]!=='')end=Math.min(Number(match[2]),end);}
   valid=valid&&Number.isSafeInteger(start)&&Number.isSafeInteger(end)&&start>=0&&start<bytes.length&&end>=start;
  }
  if(!valid){headers.set('Content-Range',`bytes */${bytes.length}`);return new Response(null,{status:416,headers});}
  status=206;body=bytes.subarray(start,end+1);headers.set('Content-Range',`bytes ${start}-${end}/${bytes.length}`);
 }
 headers.set('Content-Length',String(body.length));
 return new Response(request.method==='HEAD'?null:body,{status,headers});
}
