import {readFile,readdir,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
export async function preparePublicSource(){
 const files=['index.html','style.css','script.js','spatial-scene.js','package.json','package-lock.json','wrangler.json','schema.sql','README.md','SUBMISSION.md'];
 async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=`${dir}/${e.name}`;if(e.isDirectory())await walk(p);else if(p!=='worker/assets.generated.js')files.push(p);}}
 for(const dir of ['scripts','server','worker','drizzle','docs','tests','assets'])await walk(dir);
 // Explicit source list: never includes runtime DB, environment files, Git or deployment identity.
 execFileSync('tar',['-czf','dist/source.tar.gz',...files],{stdio:'pipe'});
 const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
 const sections=[];
 for(const file of files.filter(f=>!f.startsWith('assets/')&&f!=='package-lock.json')){
  const value=await readFile(file,'utf8');sections.push(`<details><summary>${escape(file)}</summary><pre>${escape(value)}</pre></details>`);
 }
 await writeFile('dist/source.html',`<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>과제 8 공개 소스</title><link rel="stylesheet" href="/experiment-report.css"><h1>과제 8 공개 소스</h1><p>등록·로그인·로그아웃·비공개 조회는 server/api.js에서 확인할 수 있습니다. 실제 비밀값과 로컬 계정 DB는 포함하지 않습니다.</p><p><a href="/source.tar.gz" download>영상 포함 전체 소스 내려받기</a> · <a href="/">사이트로 돌아가기</a></p>${sections.join('\n')}</html>`);
}
