import {spawnSync,spawn} from 'node:child_process';
let port='5174';const args=process.argv.slice(2);if(args.includes('--port'))port=args[args.indexOf('--port')+1];
for(const command of [['node',['scripts/build.mjs']],['npx',['wrangler','d1','execute','DB','--local','--file','schema.sql']]]){const r=spawnSync(...command,{stdio:'inherit',env:{...process.env,WRANGLER_SEND_METRICS:'false'}});if(r.status!==0)process.exit(r.status||1)}
const p=spawn('npx',['wrangler','dev','--local','--ip','localhost','--port',port],{stdio:'inherit',env:{...process.env,WRANGLER_SEND_METRICS:'false'}});p.on('exit',c=>process.exit(c||0));
