import {build} from 'esbuild';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile,cp,access} from 'node:fs/promises';
import {preparePublicSource} from './public-source.mjs';
await mkdir('dist/server',{recursive:true});
await build({entryPoints:['script.js'],outfile:'dist/client.js',bundle:true,format:'esm',target:'es2022',minify:true});
await preparePublicSource();
const assets={};
for(const [route,file,type] of [['/source','dist/source.html','text/html; charset=utf-8'],['/source.tar.gz','dist/source.tar.gz','application/gzip']])assets[route]={type,data:(await readFile(file)).toString('base64')};
const hash=async file=>createHash('sha256').update(await readFile(file)).digest('hex').slice(0,12);
let html=(await readFile('index.html','utf8')).replace('/style.css', '/style.css?v='+await hash('style.css')).replace('/script.js','/script.js?v='+await hash('dist/client.js')).replace('/assets/desk.mp4','/assets/desk.mp4?v='+await hash('assets/desk.mp4')).replace('/assets/desk-poster.jpg','/assets/desk-poster.jpg?v='+await hash('assets/desk-poster.jpg'));

for(const [route,file,type] of [['/','index.html','text/html; charset=utf-8'],['/experiment-report.css','docs/experiment-report.css','text/css; charset=utf-8'],['/experiments-report','docs/EXPERIMENTS.html','text/html; charset=utf-8'],['/experiments.md','docs/EXPERIMENTS.md','text/plain; charset=utf-8'],['/style.css','style.css','text/css; charset=utf-8'],['/script.js','dist/client.js','text/javascript; charset=utf-8'],['/assets/desk.mp4','assets/desk.mp4','video/mp4'],['/assets/desk-poster.jpg','assets/desk-poster.jpg','image/jpeg']])assets[route]={type,data:(route==='/'?Buffer.from(html):await readFile(file)).toString('base64')};
await writeFile('worker/assets.generated.js','export default '+JSON.stringify(assets)+';');
await build({entryPoints:['worker/index.js'],outfile:'dist/server/index.js',bundle:true,platform:'neutral',mainFields:['module','main'],format:'esm',target:'es2022',conditions:['workerd','browser'],external:['node:*'],minify:true});
try{await access('.openai/hosting.json');await mkdir('dist/.openai',{recursive:true});await cp('.openai/hosting.json','dist/.openai/hosting.json');}catch{}
await cp('drizzle','dist/drizzle',{recursive:true});
console.log('Built frontend + passkey Worker; private records stay in DB.');
