import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const origin='http://localhost:5174';
const checks=[];
for(const path of ['/','/script.js','/experiments-report']){
 const r=await fetch(origin+path);const t=await r.text();assert.equal(r.status,200);
 assert.ok(!t.includes('가상 프로젝트: 접근성 좋은 개인 공간을 준비합니다.'));
 assert.ok(!t.includes('의 가상 지원처: 별빛 연구소'));
 assert.ok(!/type\s*=\s*["']password["']/i.test(t));
 assert.equal(r.headers.get('x-content-type-options'),'nosniff');
 assert.match(r.headers.get('content-security-policy'),/frame-ancestors 'none'/);
 if(path==='/experiments-report'){
  assert.ok(t.includes('/experiment-report.css'));assert.ok(!t.includes('<style>'));
  assert.equal(r.headers.get('cache-control'),'no-cache');
 }
 checks.push({path,status:r.status,privateContentAbsent:true,passwordInputAbsent:true,securityHeaders:true});
}
for(const path of ['/.env','/.dev.vars','/schema.sql','/worker/index.js','/.wrangler/state','/api/vault','/api/passkeys','/api/passkeys/evidence']){
 const r=await fetch(origin+path);await r.arrayBuffer();
 const expected=path.startsWith('/api/')?401:404;assert.equal(r.status,expected);
 checks.push({path,status:r.status,expected,passed:true});
}
const result={at:new Date().toISOString(),origin,scope:'익명 읽기 전용 로컬 제출 전 점검. 공개 배포·실제 기기 증거는 포함하지 않음.',passed:true,checks};
await writeFile(new URL('../../qa/submission-local-result.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify({passed:true,checks:checks.length,statuses:checks.map(c=>({path:c.path,status:c.status}))}));
