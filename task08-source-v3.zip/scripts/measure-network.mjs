import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
const origin='http://localhost:5174';
const file=await readFile(new URL('../assets/desk.mp4',import.meta.url));
const cases=[['영상 정보만 조회','HEAD',null,200,0],['앞부분만 전송','GET','bytes=0-1023',206,1024],['중간 구간 탐색','GET','bytes=4096-5119',206,1024],['영상 끝부분 탐색','GET','bytes=-1024',206,1024],['범위 초과 거절','GET',`bytes=${file.length}-`,416,0]];
const checks=[];
for(const [name,method,range,status,length] of cases){
 const start=performance.now();
 const response=await fetch(`${origin}/assets/desk.mp4`,{method,headers:range?{Range:range}:{}});
 const bytes=Buffer.from(await response.arrayBuffer());
 assert.equal(response.status,status);assert.equal(bytes.length,length);
 if(status===206){const offset=range==='bytes=-1024'?file.length-1024:range==='bytes=4096-5119'?4096:0;assert.deepEqual(bytes,file.subarray(offset,offset+length));}
 checks.push({name,status:response.status,bytes:bytes.length,contentRange:response.headers.get('content-range'),elapsedMs:Math.round((performance.now()-start)*100)/100,passed:true});
}
for(const path of ['/api/vault','/api/passkeys/evidence']){
 const response=await fetch(origin+path);await response.arrayBuffer();assert.equal(response.status,401);
 checks.push({name:`미로그인 조회 차단 ${path}`,status:response.status,passed:true});
}
const result={at:new Date().toISOString(),environment:'localhost 개발 서버 · 실제 HTTP 요청 · 계정 변경 없음',videoBytes:file.length,checks,limits:'전송 시간은 이 컴퓨터의 단일 실행 관측값입니다. 공개망 속도나 실제 기기 패스키 검증 결과가 아닙니다.'};
await mkdir(new URL('../../qa/',import.meta.url),{recursive:true});
await writeFile(new URL('../../qa/network-measurement.json',import.meta.url),JSON.stringify(result,null,2));
const md=`# 직접 실행한 네트워크 실험\n\n실행 시각: ${result.at}\n\n${result.environment}\n\n영상 전체 크기: ${file.length.toLocaleString('en-US')} bytes\n\n| 실험 | HTTP 상태 | 전송 본문 크기 |\n|---|---:|---:|\n${checks.map(c=>`| ${c.name.replace('未','미')} | ${c.status} | ${c.bytes??'집계 제외'} |`).join('\n')}\n\n206 응답의 데이터는 원본 영상의 해당 바이트와 일치하는지 직접 비교했습니다.\n\n${result.limits}\n\n별도의 인증 프로토콜 실험은 합성 테스트 인증기로 실행한 실제 암호 검증입니다. 실제 휴대전화·보안 키의 등록 성공으로 해석하지 않습니다.\n`;
await writeFile(new URL('../docs/EXPERIMENTS.md',import.meta.url),md);
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
await writeFile(new URL('../docs/EXPERIMENTS.html',import.meta.url),`<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>실제 네트워크 실험 결과</title><link rel="stylesheet" href="/experiment-report.css"><a href="/#experiments">← 포트폴리오로 돌아가기</a><pre>${escape(md)}</pre></html>`);
console.log(JSON.stringify(result));
