# 과제 8 인증 구현 설명서 — 검토용 초안

최종 제출 전 공개 결과물·소스 HTTPS 주소와 실제 기기 검증 기록을 확인해야 합니다. 아직 직접 확인하지 않은 내용을 완료했다고 표시하지 않습니다. 이 문서의 비공개 예시는 가상 자료이며 실제 연락처·신분 정보는 사용하지 않습니다.

공개 결과물: https://hope-passkey-portfolio.mo990025.chatgpt.site/  
공개 소스: https://hope-passkey-portfolio.mo990025.chatgpt.site/source  
기존 소개 페이지: https://h0p2.github.io/-/  
기준 소스: https://github.com/H0P2/- (96e61b14f46ecdbc8dd5a55007d64a521f6f6160)

## ① 무엇으로 붙였나

표준 WebAuthn 등록·로그인을 SimpleWebAuthn 라이브러리로 검증하고 서버 세션으로 비공개 자료 조회를 허용합니다. 세션은 한 시간 만료이며 브라우저에는 HttpOnly·SameSite=Strict 쿠키, 서버에는 해당 무작위 값의 SHA-256 해시만 저장합니다. HTTPS 배포에서는 Secure도 적용합니다. 질문은 5분 만료이며 용도와 브라우저 흐름을 묶어 한 번만 소비합니다. 서버에는 credential 식별자·공개키·사용 횟수·알아볼 수 있는 이름·등록 날짜가 저장됩니다. 공개키는 서명 확인에 사용하는 값으로 비밀번호가 아닙니다. 개인키와 비밀번호는 받거나 저장하지 않습니다.

실제 저장된 공개키: **실제 등록 후 공개키 값 첨부 필요**.  
패스키 저장 위치: **사용자가 기기 등록 화면에서 선택한 실제 저장소 확인 필요**.  
개인키 미전송 증거: **등록 요청 본문 첨부 필요**. 세션·쿠키·토큰은 기록에 남기지 않습니다.

## ② 왜 그걸 골랐나

비밀번호 없이 공개 소개와 본인만 열 수 있는 공간을 분리한다는 과제 목적에 맞습니다. 서명·challenge·origin·RP ID 검증은 검증 라이브러리가 수행하고, 일회용 질문과 자료 소유권·로그아웃 처리는 서버에서 확인합니다. 화면에서만 내용을 숨기는 방식으로는 직접 자료 요청을 막을 수 없습니다.

## ③ 어디를 어떻게 고쳤나

기존 과제 1의 소개·강점·경험·관심사·프로젝트 공개 내용을 이어 사용하며, 사용자가 제공한 영상의 작업 공간을 배경으로 재구성합니다. 가상 프로젝트 메모·가상 지원 계획·가상 회고 세 항목은 인증 후에만 서버가 전송합니다.

| 흐름 | 요청 | 소스 위치 |
| --- | --- | --- |
| 등록 | `/api/passkeys/register/options`, `/verify`, `/cancel` | `server/api.js`: `registrationOptions`, `registrationVerify`, `consumeFlow` 및 취소 분기 |
| 로그인 | `/api/passkeys/authenticate/options`, `/verify` | `server/api.js`: `authenticationOptions`, `authenticationVerify`, `createSession` |
| 로그아웃 | `/api/logout` | `server/api.js`: `handleApi` 로그아웃 분기에서 서버 세션 삭제 |
| 비공개 조회·다른 계정 차단 | `/api/vault`, `/api/vault/:owner` | `server/api.js`: `requireUser`, `current`, `handleApi` vault 분기와 `account_id` 조건 |

## ④ 안 열리는 것을 확인한 기록

`tests/live-protocol.mjs` 자동 암호 검증은 합성 P-256 열쇠로 실제 서명을 만들어 로컬 서버에 보내는 프로토콜 테스트입니다. 15개 성공·거절 비교가 통과했습니다. 결과는 `docs/evidence/synthetic-protocol-result.json`에 있으며 실제 기기 증거로 간주하지 않습니다. 실제 사람이 기기에서 등록·인증한 증거와는 구분합니다. 아래 기록은 실제 검증을 끝낸 뒤 성공·거절 응답을 함께 첨부해야 합니다.

| 확인 | 성공한 요청 | 거절된 요청 | 현재 실제 기기 증거 |
| --- | --- | --- | --- |
| 로그인 없이 비공개 주소 열기 | 본인 패스키 인증 뒤 조회 200 | 익명 조회 401/403 | 미확인 |
| 남의 패스키로 열기 | A·B 각각 본인 자료 조회 200 | A→B, B→A 거절 및 전후 건수 동일 | 미확인 |
| 이미 쓴 질문 재사용 | 새 질문에 대한 정상 서명 로그인 | 동일 질문·응답 재전송 거절 | 미확인 |
| 패스키 삭제 뒤 로그인 | 남은 별도 credential 로그인 | 삭제한 credential 로그인 거절 | 미확인 |

등록·로그인 질문 각각 두 값의 차이, 정상 서명과 잘못된 서명 응답, 로그아웃 이후 동일 세션의 거절 응답도 첨부합니다. 세션 값은 `[가림]`으로 표시합니다. 서버에 저장된 공개키는 공개 가능하지만 세션 값은 공개하지 않습니다.

## ⑤ AI와 나

- AI에게 맡긴 일: 영상 참고 화면 구현, 패스키 서버 인증 흐름, 검증 도구와 설명서 초안 작성.
- 내가 직접 판단한 일: 기존 소개 페이지 유지, 제공 영상 선택, 실제 기기 패스키 저장소 선택과 두 계정·두 credential 등록, 삭제 대상 및 최종 제출 검토. **등록·삭제 선택은 아직 수행 전입니다.**
- AI 제안을 따르지 않은 일: **사용자가 최종 검토에서 작성**. 없다면 무엇을 확인하여 그대로 채택했는지 적습니다. AI가 사용자의 선택 이유를 임의로 만들지 않습니다.

## ⑥ 아직 못 막은 것

모든 패스키와 동기화 저장소 접근을 동시에 잃으면 계정의 비공개 자료에 다시 접근할 수 없습니다. 인증을 우회하는 비밀번호 복구는 제공하지 않습니다. 기기 또는 잠금 해제된 패스키 저장소가 타인에게 넘어가는 위험까지 서버가 없앨 수는 없습니다. 유효한 세션을 탈취당하면 만료 전에 자료 조회나 패스키 관리가 가능할 수 있습니다. HttpOnly·Secure·SameSite 쿠키와 세션 만료를 적용하지만 이 위험을 완전히 없애지는 못합니다. 스크롤 영상 디코딩과 패스키 지원은 브라우저·기기에 따라 차이가 있어 실제 사용 기기 확인이 필요합니다.

## 짧은 확인 방법 4줄

1. 어디로 가나요: 확정된 공개 결과물 HTTPS 주소의 소개 첫 화면으로 갑니다.
2. 세 단계 안에 무엇을 하나요: 공개 소개 확인 → 패스키로 비공개 공간 로그인 → 본인 가상 메모와 패스키 목록 확인.
3. 무엇이 보이면 통과인가요: 공개 소개는 로그인 없이 열리고, 본인 인증 후에만 본인 가상 자료가 보입니다.
4. 안 될 때는 무엇이 보이나요: 인증 취소·지원 불가 안내 또는 401/403 거절이 보이며 비공개 원문은 응답에 포함되지 않습니다.

## 실제 사용자 확인이 필요한 것

- 별도 패스키를 가진 두 계정과 서로 다른 가상 자료를 확인합니다.
- 한 계정에 서로 다른 credential 두 개를 등록하고 이름·날짜·실제 저장 위치를 확인합니다. 동일 credential의 기기 동기화는 두 개로 세지 않습니다.
- 대체 패스키로 접근할 수 있음을 먼저 확인한 다음 삭제할 패스키를 선택하고 삭제를 승인합니다.
- 남은 패스키 성공과 삭제한 패스키 거절을 확인합니다. 마지막 패스키가 없어지면 접근을 복구할 수 없습니다.
- 새 시크릿 창에서 결과물·소스 주소의 공개 접근을 확인하고 최종 제출을 검토합니다.

## 로컬 자동 검증 부록 — 실제 사용자 기기 증거 아님

합성 인증기가 실제 P-256 서명을 사용한 개발 서버 검증입니다. 운영 계정이나 실제 기기 저장소를 확인한 것으로 간주하지 않습니다. 성공·거절 비교 15개와 요청/응답 58개를 `docs/evidence/synthetic-protocol-result.json`에 기록했습니다. 쿠키 원문은 `[가림]`으로 처리했습니다.

등록 challenge 두 값:

```text
9STpH8K1fsdcBLW043RvYwRMW-MT3s43KXfk3skEq-U
mxL_h8c5RgZ2tOUFueIOLCGo0ca87oy7RAWVySCBNCw
```

로그인 challenge 두 값:

```text
4RUlh6JZwZS8ZRDU6TPAK-Ha1ifi5MPjx9A8NTuZ0gA
ewsNyu2OCc-NoAOGENXBn0X-AzF-V1wdZI_8Tjq0aNA
```

서버 저장값과 대조한 합성 공개키(COSE/base64url):

```text
pQECAyYgASFYII36hEwjqFwxYTylJM70ynUYlivPFZ2pkPfYc6dCOzvSIlggXAn0hs2E49TTIdWLWCSQPld9D5DAHMfmfKW41jx3Jk4
```

이 값은 서명 검증용 공개키이며 비밀번호나 개인키가 아닙니다. 등록 요청 본문 전체는 같은 결과 파일의 `registrationRequest`에 있습니다. 본문에는 credential 식별자, clientDataJSON, attestationObject 등 공개 검증 응답이 있으며 개인키는 포함되지 않습니다.

| 검증 | 성공 | 거절 |
| --- | --- | --- |
| anonymous private request | 200 | 401 |
| account A to B | 200 | 403 |
| account B to A | 200 | 403 |
| logout old session rejection | 200 | 401 |
| challenge replay | 200 | 400 |
| correct versus incorrect cryptographic signature | 200 | 401 |
| missing user verification | 200 | 401 |
| wrong challenge | 200 | 401 |
| wrong user handle | 200 | 401 |
| signed response with wrong origin | 200 | 401 |
| atomic challenge use under concurrent replay | 200 | 400 |
| controlled local challenge expiry | 200 | 400 |
| deleted versus remaining credential | 200 | 401 |
| controlled local session expiry | 200 | 401 |

각 요청의 경로·방식·본문과 응답은 `exchanges`에서 나란히 확인할 수 있습니다. 실제 두 계정과 실제 기기 패스키 저장소·삭제 뒤 인증 증거는 여전히 미확인입니다.

## 추가 로컬 운영 점검

2026-10-12 서울 시각에 실제 HTTP 요청 7건으로 영상 HEAD·앞/중간/끝 Range·범위 초과·익명 개인자료 조회·익명 공개키 조회를 확인했습니다. 영상 구간 응답 206의 바이트가 원본과 일치하며 범위 초과 416, 익명 조회는 두 건 모두 401입니다. 상세 측정은 `docs/EXPERIMENTS.md`에 있습니다. 기존 합성 인증 검증과 이번 조회 실험은 공개 주소에서의 실제 기기 등록 증거를 대체하지 않습니다.

최신 로컬 인증 검증 시각(UTC): 2026-10-11T22:32:28.662Z . 제출 전 익명 조회·파일 노출·보안 헤더 점검 11건도 통과했으며 `docs/evidence/submission-local-result.json`에 기록했습니다. 실제 기기 등록·공개 주소는 여전히 미확인입니다.
