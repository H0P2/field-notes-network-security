CREATE TABLE IF NOT EXISTS accounts (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS credentials (
 id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id), public_key TEXT NOT NULL,
 counter INTEGER NOT NULL, name TEXT NOT NULL, created_at INTEGER NOT NULL,
 transports TEXT NOT NULL, device_type TEXT NOT NULL, backed_up INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS credential_owner ON credentials(account_id);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id),
 credential_id TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS session_expiry ON sessions(expires_at);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS challenges (
 flow_hash TEXT PRIMARY KEY, challenge TEXT NOT NULL, kind TEXT NOT NULL,
 account_id TEXT, username TEXT, credential_name TEXT,
 is_new INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
 used INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS vault_items (
 id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id), title TEXT NOT NULL, content TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS vault_owner ON vault_items(account_id);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS request_limits (
 bucket TEXT PRIMARY KEY, attempt_count INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
--> statement-breakpoint
