import * as THREE from 'three';
export function initSpatialScene() {
 const home=document.getElementById('home'), stage=home.querySelector('.spatial-stage');
 const video=document.getElementById('desk-video'),canvas=document.getElementById('spatial-canvas');
 const toggle=document.getElementById('motion-toggle'),label=document.getElementById('scroll-progress'),note=document.getElementById('scene-status');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let enabled=!reduced.matches,renderer,scene,camera,screen,texture,poster,monitor;
 let pending=false,progress=0,targetTime=0,visible=true,pointer={x:0,y:0},lost=false,decodedFrame=false,travelFrame=0,travelling=false;
 video.pause(); video.preload='auto';
 function fallback(message){home.classList.remove('webgl-ready');home.dataset.renderer='fallback';canvas.hidden=true;note.textContent=message;note.hidden=false;renderer=undefined;}
 try {
  renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;
  scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(48,1,.1,100);
  monitor=new THREE.Group();scene.add(monitor);
  poster=new THREE.TextureLoader().load(video.getAttribute('poster')||'/assets/desk-poster.jpg',()=>queue());poster.colorSpace=THREE.SRGBColorSpace;
  texture=new THREE.VideoTexture(video);texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=THREE.LinearFilter;texture.magFilter=THREE.LinearFilter;
  screen=new THREE.Mesh(new THREE.PlaneGeometry(4.5,4.5),new THREE.MeshBasicMaterial({map:poster,toneMapped:false}));monitor.add(screen);
  scene.add(new THREE.HemisphereLight(0x9fe5e1,0x061316,2));const light=new THREE.DirectionalLight(0x70d9d3,3);light.position.set(-3,5,4);scene.add(light);
  home.dataset.renderer='webgl';canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;fallback('3D 화면을 사용할 수 없어 영상 화면으로 전환했습니다. 소개와 패스키 기능은 계속 사용할 수 있습니다.');});
 }catch{fallback('이 기기에서는 3D 화면 대신 스크롤 영상으로 공간을 보여드립니다.');}
 function seek(){if(travelling||!enabled||!Number.isFinite(video.duration)||video.readyState<1)return;if(!video.seeking&&Math.abs(video.currentTime-targetTime)>.025){video.currentTime=targetTime;}}
 function update(){
  pending=false;const rect=home.getBoundingClientRect(),distance=Math.max(1,home.offsetHeight-stage.clientHeight);
  progress=enabled?THREE.MathUtils.clamp(-rect.top/distance,0,1):0;
  home.dataset.scrollProgress=progress.toFixed(4);home.style.setProperty('--journey-progress',progress);
  label.textContent=enabled?`공간 탐험 ${Math.round(progress*100)}% · 스크롤로 이동`:'움직임을 줄인 화면';
  const entrance=THREE.MathUtils.clamp(progress/.70,0,1);
  home.style.setProperty('--entrance-progress',entrance);
  const depth=THREE.MathUtils.smoothstep(entrance,.28,1);
  home.style.setProperty('--screen-depth',depth);
  home.style.setProperty('--fallback-zoom',1+depth*.35);
  const portal=document.getElementById('project-portal');
  const portalThreshold=home.dataset.portalOpen==='true'?.58:.68;
  const open=enabled?progress>=portalThreshold&&!travelling:home.dataset.portalOpen==='true';home.dataset.portalOpen=String(open);if(portal)portal.setAttribute('aria-hidden',String(!open));
  targetTime=entrance*Math.max(0,(video.duration||0)-.045);seek();
  if(renderer&&!lost){
   const w=stage.clientWidth,h=stage.clientHeight,mobile=w<=640;
   const resolution=Math.min(devicePixelRatio,2,Math.sqrt(4000000/(w*h)));
   if(Math.abs(renderer.getPixelRatio()-resolution)>.01)renderer.setPixelRatio(resolution);
   if(canvas.width!==Math.round(w*renderer.getPixelRatio())||canvas.height!==Math.round(h*renderer.getPixelRatio()))renderer.setSize(w,h,false);
   camera.aspect=w/h;camera.fov=48-depth*4;camera.updateProjectionMatrix();
   const tangent=Math.tan(THREE.MathUtils.degToRad(48/2));
   const baseZ=5.5;
   camera.position.set(pointer.x*.025,pointer.y*.025,baseZ-entrance*.9-depth*.55);
   const side=2*tangent*baseZ*Math.max(1,camera.aspect)*1.025;
   monitor.scale.setScalar(side/4.5);
   monitor.position.set(0,0,0);
   monitor.rotation.set(pointer.y*.004,pointer.x*.004,0);
   camera.lookAt(0,0,0);
   // Keep the last decoded frame while seeking; never upload an incomplete frame.
   const nextMap=enabled&&decodedFrame?texture:poster;
   if(screen.material.map!==nextMap){screen.material.map=nextMap;screen.material.needsUpdate=true;}
   renderer.render(scene,camera);
   home.classList.toggle('webgl-ready',enabled);canvas.hidden=!enabled;
   home.dataset.cameraZ=camera.position.z.toFixed(3);
  }
 }
 function queue(){if(!pending&&!document.hidden){pending=true;requestAnimationFrame(update);}}
 function frameReady(){if(video.readyState>=2&&!video.seeking){decodedFrame=true;if(texture)texture.needsUpdate=true;}queue();}
 video.addEventListener('loadeddata',frameReady);video.addEventListener('loadedmetadata',queue);
 video.addEventListener('seeked',frameReady);
 if('requestVideoFrameCallback' in video){
  const decoded=()=>{frameReady();video.requestVideoFrameCallback(decoded);};
  video.requestVideoFrameCallback(decoded);
 }
 video.addEventListener('error',()=>{note.textContent='영상을 불러오지 못해 첫 장면을 표시합니다.';note.hidden=false;queue();});
 window.addEventListener('scroll',queue,{passive:true});window.addEventListener('resize',queue,{passive:true});
 stage.addEventListener('pointermove',e=>{if(!enabled||e.pointerType==='touch'||!visible)return;const r=stage.getBoundingClientRect();pointer={x:(e.clientX-r.left)/r.width-.5,y:(e.clientY-r.top)/r.height-.5};queue();});
 stage.addEventListener('pointerleave',()=>{pointer={x:0,y:0};queue();});
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)queue();}).observe(home);
 function toggleLabel(){toggle.textContent=enabled?'스크롤 효과 끄기':'스크롤 효과 켜기';toggle.setAttribute('aria-pressed',String(!enabled));home.classList.toggle('motion-disabled',!enabled);}
 toggle.addEventListener('click',()=>{enabled=!enabled;video.pause();toggleLabel();home.scrollIntoView({block:'start',behavior:'instant'});queue();});
 reduced.addEventListener('change',()=>{stopTravel();enabled=!reduced.matches;video.pause();toggleLabel();queue();});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)queue();});
 function stopTravel(){if(travelFrame)cancelAnimationFrame(travelFrame);travelFrame=0;travelling=false;video.pause();home.dataset.entering='false';home.style.setProperty('--warp-strength',0);queue();}
 function travelTo(end,entering){
  stopTravel();
  const start=scrollY,begin=performance.now(),duration=entering?3200:1200;
  if(!enabled){window.scrollTo({top:end,behavior:'instant'});queue();return;}
  travelling=entering;home.dataset.entering=String(entering);
  if(entering&&video.readyState>=2&&Number.isFinite(video.duration)){
   const remaining=Math.max(0,video.duration-.045-video.currentTime);
   video.playbackRate=Math.max(.25,Math.min(4,remaining/(duration/1000)));
   video.play().catch(()=>{});
  }
  function tick(now){
   const t=Math.min(1,(now-begin)/duration),ease=(1-Math.cos(Math.PI*t))/2;
   home.style.setProperty('--warp-strength',entering?Math.sin(Math.PI*t)**2:0);
   window.scrollTo({top:start+(end-start)*ease,behavior:'instant'});update();
   if(t<1)travelFrame=requestAnimationFrame(tick);
   else{travelFrame=0;travelling=false;video.pause();home.dataset.entering='false';home.style.setProperty('--warp-strength',0);update();requestAnimationFrame(()=>document.getElementById(entering?'portal-title':'enter-screen').focus({preventScroll:true}));}
  }
  travelFrame=requestAnimationFrame(tick);
 }
 function enter(){
  if(travelling)return;
  const start=home.getBoundingClientRect().top+scrollY;
  if(!enabled){
   // Static access is still available without any zoom or video motion.
   window.scrollTo({top:home.getBoundingClientRect().top+scrollY,behavior:'instant'});
   home.dataset.portalOpen='true';document.getElementById('project-portal').setAttribute('aria-hidden','false');
   document.getElementById('portal-title').focus({preventScroll:true});
   requestAnimationFrame(()=>window.scrollTo({top:start,behavior:'instant'}));return;
  }
  travelTo(start+(home.offsetHeight-stage.clientHeight)*.85,true);
 }
 document.getElementById('enter-screen').addEventListener('click',enter);
 document.getElementById('exit-screen').addEventListener('click',event=>{
  event.stopPropagation();
  stopTravel();home.dataset.portalOpen='false';document.getElementById('project-portal').setAttribute('aria-hidden','true');
  const top=home.getBoundingClientRect().top+scrollY;
  window.scrollTo({top,behavior:'instant'});update();
  document.getElementById('enter-screen').focus({preventScroll:true});
  requestAnimationFrame(()=>{document.getElementById('enter-screen').focus({preventScroll:true});window.scrollTo({top,behavior:'instant'});});
 });
 document.querySelectorAll('a[href="#project-portal"]').forEach(link=>link.addEventListener('click',event=>{event.preventDefault();enter();}));
 const tabs=[...document.querySelectorAll('.desktop-tabs [role="tab"]')];
 function choose(tab){
  tabs.forEach(t=>{const selected=t===tab;t.setAttribute('aria-selected',String(selected));t.tabIndex=selected?0:-1;document.getElementById(t.getAttribute('aria-controls')).hidden=!selected;});
 }
 tabs.forEach((tab,i)=>{
  tab.addEventListener('click',()=>choose(tab));
  tab.addEventListener('keydown',e=>{let next;if(e.key==='ArrowRight')next=(i+1)%tabs.length;else if(e.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=tabs.length-1;if(next!==undefined){e.preventDefault();choose(tabs[next]);tabs[next].focus();}});
 });
 window.addEventListener('wheel',stopTravel,{passive:true});window.addEventListener('touchstart',stopTravel,{passive:true});
 window.addEventListener('keydown',e=>{if(['Escape','PageUp','PageDown','ArrowUp','ArrowDown'].includes(e.key))stopTravel();});
 toggle.addEventListener('click',stopTravel);
 toggleLabel();queue();
}
