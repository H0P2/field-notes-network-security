import test from 'node:test';
import assert from 'node:assert/strict';
import {handleApi} from '../server/api.js';
const origin='http://localhost:5174';
const env={APP_ORIGIN:origin,DB:{prepare(sql){
 assert.ok(!sql.includes('SELECT id FROM accounts'),'Adding without a session must not fall back to signup lookup');
 return {bind(){return this},async first(){return {attempt_count:1}},async run(){return {success:true}}};
},async batch(){return []}}};
test('session observation cannot expire a newer login cookie through a late response',async()=>{
 const response=await handleApi(new Request(origin+'/api/session'),env);
 assert.equal(response.status,200);assert.deepEqual(await response.json(),{authenticated:false});
 assert.equal(response.headers.get('Set-Cookie'),null);
});
test('adding without a valid session asks for login instead of duplicate signup',async()=>{
 const response=await handleApi(new Request(origin+'/api/passkeys/register/options',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({username:'existing_user',name:'Second key',mode:'add'})}),env);
 assert.equal(response.status,401);assert.equal((await response.json()).error,'authentication_required');
});
