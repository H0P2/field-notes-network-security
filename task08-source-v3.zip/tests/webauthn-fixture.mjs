// Real cryptographic protocol fixtures. These are NOT native-device usage evidence.
import { createHash, generateKeyPairSync, randomBytes, sign } from 'node:crypto';

const b64 = (value) => Buffer.from(value).toString('base64url');
const hash = (value) => createHash('sha256').update(value).digest();

function head(major, length) {
  if (length < 24) return Buffer.from([(major << 5) | length]);
  if (length < 256) return Buffer.from([(major << 5) | 24, length]);
  if (length < 65536) {
    const out = Buffer.alloc(3); out[0] = (major << 5) | 25; out.writeUInt16BE(length, 1); return out;
  }
  throw new Error('Fixture CBOR length too large');
}

export function cbor(value) {
  if (typeof value === 'number') return value >= 0 ? head(0, value) : head(1, -1 - value);
  if (typeof value === 'string') { const bytes = Buffer.from(value); return Buffer.concat([head(3, bytes.length), bytes]); }
  if (Buffer.isBuffer(value)) return Buffer.concat([head(2, value.length), value]);
  const entries = value instanceof Map ? [...value] : Object.entries(value);
  return Buffer.concat([head(5, entries.length), ...entries.flatMap(([key, item]) => [cbor(key), cbor(item)])]);
}

export function makeAuthenticator() {
  const { publicKey, privateKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const id = randomBytes(32);
  let counter = 0;
  const cose = cbor(new Map([[1, 2], [3, -7], [-1, 1], [-2, Buffer.from(jwk.x, 'base64url')], [-3, Buffer.from(jwk.y, 'base64url')]]));
  const makeClientData = (type, challenge, origin) => Buffer.from(JSON.stringify({ type, challenge, origin, crossOrigin: false }));
  const authData = (rpID, flags, count) => {
    const tail = Buffer.alloc(5); tail[0] = flags; tail.writeUInt32BE(count, 1);
    return Buffer.concat([hash(rpID), tail]);
  };
  return {
    id: b64(id),
    publicKey: b64(cose),
    registration(options, origin, overrides = {}) {
      const client = makeClientData('webauthn.create', overrides.challenge ?? options.challenge, origin);
      const idLength = Buffer.alloc(2); idLength.writeUInt16BE(id.length);
      const data = Buffer.concat([authData(options.rp.id, 0x45, 0), Buffer.alloc(16), idLength, id, cose]);
      return { id: b64(id), rawId: b64(id), type: 'public-key', authenticatorAttachment: 'platform', clientExtensionResults: {},
        response: { clientDataJSON: b64(client), attestationObject: b64(cbor({ fmt: 'none', attStmt: {}, authData: data })), transports: ['internal'] } };
    },
    authentication(options, origin, overrides = {}) {
      const client = makeClientData('webauthn.get', overrides.challenge ?? options.challenge, origin);
      const data = authData(options.rpId, overrides.flags ?? 0x05, ++counter);
      let signature = sign('sha256', Buffer.concat([data, hash(client)]), privateKey);
      if (overrides.badSignature) signature = Buffer.alloc(signature.length, 0);
      return { id: b64(id), rawId: b64(id), type: 'public-key', authenticatorAttachment: 'platform', clientExtensionResults: {},
        response: { clientDataJSON: b64(client), authenticatorData: b64(data), signature: b64(signature), userHandle: overrides.userHandle ?? null } };
    },
  };
}
