import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

// Execute the shipped UI source, substituting only its browser/library environment.
const shippedSource = await readFile(new URL('../script.js', import.meta.url), 'utf8');
const executableSource = shippedSource.replace(/^import .*;\r?\n/gm, '') + '\n;globalThis.ui = { loadAccount, refreshSession, clearPrivate, setBusy };';
const tick = () => new Promise(resolve => setImmediate(resolve));
const owner = { id: 'fixture-a', username: 'fixture_a' };
const fixtureItem = { id: 'item-a', title: 'Private fixture A', content: 'Synthetic regression fixture only' };
const fixtureKey = { id: 'key-a', name: 'Fixture key', createdAt: '2026-10-11T00:00:00.000Z' };

class Element {
  constructor(tag = 'div') {
    this.tagName = tag; this.dataset = {}; this.attributes = {}; this.children = [];
    this.listeners = {}; this.hidden = false; this.disabled = false; this.textContent = '';
  }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = children.flatMap(child => child.tagName === '#fragment' ? child.children : [child]); }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  addEventListener(name, listener) { (this.listeners[name] ||= []).push(listener); }
  querySelector() { return this.button ||= new Element('button'); }
  focus() {}
}

async function harness() {
  const elements = new Map();
  const get = id => {
    if (!elements.has(id)) elements.set(id, new Element());
    return elements.get(id);
  };
  get('account-panel').hidden = true;
  const requests = [];
  const fetch = (path, options) => new Promise(resolve => requests.push({path, options, resolve, settled: false}));
  const context = vm.createContext({
    document: {
      body: new Element(), hidden: false, getElementById: get,
      querySelectorAll: () => [], addEventListener() {},
      createElement: tag => new Element(tag), createDocumentFragment: () => new Element('#fragment'),
    },
    fetch, initSpatialScene() {}, browserSupportsWebAuthn: () => true,
    startRegistration: async () => { throw new Error('Native credential operations are outside these tests'); },
    startAuthentication: async () => { throw new Error('Native credential operations are outside these tests'); },
    indexedDB: { open() { throw new Error('Local metrics are outside this test'); } },
    setInterval() {}, window: { confirm: () => true }, console,
  });
  vm.runInContext(executableSource, context, {filename: 'script.js'});
  const respond = (path, body, status = 200) => {
    const request = requests.find(item => item.path === path && !item.settled);
    assert.ok(request, `Expected pending ${path}`);
    request.settled = true;
    request.resolve({ok: status >= 200 && status < 300, status, json: async () => body});
  };
  respond('/api/session', {authenticated: false});
  await tick();
  const finishAccount = () => {
    respond('/api/vault', {user: owner, items: [fixtureItem], count: 1});
    respond('/api/passkeys', {passkeys: [fixtureKey]});
  };
  const assertClosed = () => {
    assert.equal(get('account-panel').hidden, true);
    assert.equal(get('auth-panel').hidden, false);
    assert.equal(get('account-name').textContent, '');
    assert.equal(get('private-items').children.length, 0);
    assert.equal(get('key-list').children.length, 0);
  };
  return {ui: context.ui, get, requests, respond, finishAccount, assertClosed};
}

test('current account response still renders genuine returned items and keys', async () => {
  const h = await harness();
  const pending = h.ui.loadAccount(owner);
  h.finishAccount(); await pending;
  assert.equal(h.get('account-panel').hidden, false);
  assert.equal(h.get('account-name').textContent, owner.username);
  assert.equal(h.get('private-items').children[0].children[0].textContent, fixtureItem.title);
  assert.equal(h.get('key-list').children[0].children[0].children[0].textContent, fixtureKey.name);
});

for (const boundary of ['clearPrivate', 'setBusy']) {
  test(`late account reads cannot repaint after ${boundary}`, async () => {
    const h = await harness();
    const pending = h.ui.loadAccount(owner);
    h.ui[boundary](true);
    h.finishAccount(); await pending;
    h.assertClosed();
  });

  test(`late authenticated session response cannot start account reads after ${boundary}`, async () => {
    const h = await harness();
    const pending = h.ui.refreshSession();
    h.ui[boundary](true);
    h.respond('/api/session', {authenticated: true, user: owner});
    await pending;
    assert.equal(h.requests.filter(request => request.path === '/api/vault').length, 0);
    assert.equal(h.requests.filter(request => request.path === '/api/passkeys').length, 0);
    h.assertClosed();
  });
}

test('real logout handler wins over an already started refresh vault response', async () => {
  const h = await harness();
  const refresh = h.ui.refreshSession();
  h.respond('/api/session', {authenticated: true, user: owner});
  await tick(); // The old refresh has advanced into /vault and /passkeys reads.
  assert.equal(h.requests.some(request => request.path === '/api/vault'), true);
  const logout = h.get('logout').listeners.click[0]();
  h.respond('/api/logout', {ok: true});
  await logout;
  h.assertClosed();
  h.finishAccount(); await refresh;
  h.assertClosed();
  assert.match(h.get('auth-status').textContent, /로그아웃했습니다/);
});
