import test from 'node:test';
import assert from 'node:assert/strict';
import { generateRegistrationOptions, verifyRegistrationResponse, generateAuthenticationOptions, verifyAuthenticationResponse } from '@simplewebauthn/server';
import { makeAuthenticator } from './webauthn-fixture.mjs';

test('real P-256 signature verified by production WebAuthn library; tampering rejected',async()=>{
  const origin='http://localhost:5174',rpID='localhost';
  const authenticator=makeAuthenticator();
  const options=await generateRegistrationOptions({rpName:'Protocol fixture',rpID,userID:new TextEncoder().encode('fictional-account'),userName:'fictional-account',attestationType:'none',authenticatorSelection:{residentKey:'required',userVerification:'required'},supportedAlgorithmIDs:[-7]});
  const registration=await verifyRegistrationResponse({response:authenticator.registration(options,origin),expectedChallenge:options.challenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:true});
  assert.equal(registration.verified,true);
  assert.equal(Buffer.from(registration.registrationInfo.credential.publicKey).toString('base64url'),authenticator.publicKey);
  const login=await generateAuthenticationOptions({rpID,userVerification:'required'});
  assert.notEqual(options.challenge,login.challenge);
  const config={expectedChallenge:login.challenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:true,credential:registration.registrationInfo.credential};
  const good=await verifyAuthenticationResponse({...config,response:authenticator.authentication(login,origin)});
  assert.equal(good.verified,true);
  await assert.rejects(()=>verifyAuthenticationResponse({...config,response:authenticator.authentication(login,origin,{flags:0x01})}));
  await assert.rejects(()=>verifyAuthenticationResponse({...config,response:authenticator.authentication(login,'https://different.invalid')}));
  const bad=await verifyAuthenticationResponse({...config,response:authenticator.authentication(login,origin,{badSignature:true})}).catch(()=>({verified:false}));
  assert.equal(bad.verified,false);
});
