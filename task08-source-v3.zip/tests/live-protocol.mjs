import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { makeAuthenticator } from './webauthn-fixture.mjs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const origin = process.env.TEST_ORIGIN || 'http://localhost:5174';
assert.equal(new URL(origin).hostname,'localhost','Synthetic accounts must only be created in local development.');
const evidence = [];
const exchanges = [];
const localSql = (sql) => execFileSync(process.execPath,[fileURLToPath(new URL('../node_modules/wrangler/bin/wrangler.js',import.meta.url)),'d1','execute','DB','--local','--command',sql],{cwd:fileURLToPath(new URL('../',import.meta.url)),stdio:'pipe',env:{...process.env,WRANGLER_SEND_METRICS:'false'}});
class Client {
  jar = new Map();
  async request(path, method = 'GET', body, cookieOverride) {
    const headers = { Origin: origin };
    if (method !== 'GET') headers['Content-Type'] = 'application/json';
    const cookie = cookieOverride ?? [...this.jar].map(([k,v]) => `${k}=${v}`).join('; ');
    if (cookie) headers.Cookie = cookie;
    const response = await fetch(`${origin}${path}`, { method, headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    for (const item of response.headers.getSetCookie()) {
      const [pair] = item.split(';'); const index = pair.indexOf('=');
      const name = pair.slice(0,index), value = pair.slice(index + 1);
      if (/Max-Age=0(?:;|$)/i.test(item)) this.jar.delete(name); else this.jar.set(name, value);
    }
    const data = await response.json();
    exchanges.push({request:{method,path,headers:{Origin:origin,...(cookie?{Cookie:'[가림]'}:{})},...(body===undefined?{}:{body})},response:{status:response.status,data}});
    return { status: response.status, data };
  }
  cookie() { return [...this.jar].map(([k,v]) => `${k}=${v}`).join('; '); }
}
function record(name, good, bad) {
  evidence.push({ name, success: good, denial: bad });
}
async function register(client, key, username, name) {
  const result = await client.request('/api/passkeys/register/options','POST',{username,name});
  assert.equal(result.status,200,JSON.stringify(result));
  const response = key.registration(result.data.options,origin);
  const verify = await client.request('/api/passkeys/register/verify','POST',response);
  assert.equal(verify.status,200,JSON.stringify(verify));
  return { ...verify, challenge: result.data.options.challenge, request: response };
}
async function login(client,key,badSignature=false) {
  const options = await client.request('/api/passkeys/authenticate/options','POST',{});
  assert.equal(options.status,200);
  const payload = key.authentication(options.data.options,origin,{badSignature});
  const flowCookie = client.cookie();
  const result = await client.request('/api/passkeys/authenticate/verify','POST',payload);
  return { ...result, challenge: options.data.options.challenge, payload, flowCookie };
}

const a = new Client(), b = new Client(), anon = new Client();
const first = makeAuthenticator(), second = makeAuthenticator(), other = makeAuthenticator();
const suffix = `${Date.now().toString(36)}`;
const usernameA = `fixture_a_${suffix}`, usernameB = `fixture_b_${suffix}`;
const anonymous = await anon.request('/api/vault'); assert.equal(anonymous.status,401);
const html = await (await fetch(origin)).text();
assert.ok(!html.includes('가상 프로젝트: 접근성 좋은 개인 공간을 준비합니다.'));
assert.ok(!/type\s*=\s*["']password["']/i.test(html));
const registerA = await register(a,first,usernameA,'합성 기기 A1');
const registerB = await register(b,other,usernameB,'합성 기기 B1');
assert.notEqual(registerA.challenge,registerB.challenge);
const accountA = registerA.data.user.id, accountB = registerB.data.user.id;
const ownA = await a.request('/api/vault'), ownB = await b.request('/api/vault');
assert.equal(ownA.status,200); assert.equal(ownB.status,200);
assert.equal(ownA.data.count,3); assert.equal(ownB.data.count,3);
assert.notDeepEqual(ownA.data.items,ownB.data.items);
record('anonymous private request',ownA,anonymous);
const aToB = await a.request(`/api/vault/${accountB}`), bToA = await b.request(`/api/vault/${accountA}`);
assert.equal(aToB.status,403); assert.equal(bToA.status,403);
assert.equal((await a.request('/api/vault')).data.count,ownA.data.count);
assert.equal((await b.request('/api/vault')).data.count,ownB.data.count);
record('account A to B',ownB,aToB); record('account B to A',ownA,bToA);
const forged = await a.request(`/api/vault?owner=${accountB}`);
assert.equal(forged.status,200); assert.equal(forged.data.user.id,accountA);
assert.deepEqual(forged.data.items,ownA.data.items);
evidence.push({name:'forged owner query ignored',response:forged,countsBefore:{a:3,b:3},countsAfter:{a:3,b:3}});
const duplicate = await anon.request('/api/passkeys/register/options','POST',{username:usernameA,name:'침입 시도'});
assert.equal(duplicate.status,409);
const cancellation = new Client();
await cancellation.request('/api/passkeys/register/options','POST',{username:`cancel_${suffix}`,name:'취소 기기'});
assert.equal((await cancellation.request('/api/passkeys/register/cancel','POST',{})).status,200);
const retryCanceled = await cancellation.request('/api/passkeys/register/options','POST',{username:`cancel_${suffix}`,name:'취소 기기'});
assert.equal(retryCanceled.status,200);
await cancellation.request('/api/passkeys/register/cancel','POST',{});
await register(a,second,usernameA,'합성 기기 A2');
const list = await a.request('/api/passkeys'); assert.equal(list.data.passkeys.length,2);
assert.ok(list.data.passkeys.every(row=>row.name&&row.createdAt));
const publicKeys = await a.request('/api/passkeys/evidence');
assert.equal(publicKeys.data.passkeys.find(row=>row.id===first.id).publicKey,first.publicKey);
assert.ok(!JSON.stringify(publicKeys.data).includes('privateKey'));
const oldSession = a.cookie();
await a.request('/api/logout','POST',{});
const revoked = await a.request('/api/vault','GET',undefined,oldSession); assert.equal(revoked.status,401);
record('logout old session rejection',ownA,revoked);
const success = await login(a,first); assert.equal(success.status,200);
const replay = await a.request('/api/passkeys/authenticate/verify','POST',success.payload,success.flowCookie); assert.equal(replay.status,400);
record('challenge replay', {status:success.status,data:success.data,challenge:success.challenge},replay);
const malformed = await login(anon,first,true); assert.equal(malformed.status,401);
assert.notEqual(success.challenge,malformed.challenge);
record('correct versus incorrect cryptographic signature',{status:success.status,data:success.data}, {status:malformed.status,data:malformed.data});
for (const [name,override] of [['missing user verification',{flags:0x01}],['wrong challenge',{challenge:'different-question'}],['wrong user handle',{userHandle:'wrong-account'}]]) {
  const opts=await anon.request('/api/passkeys/authenticate/options','POST',{});
  const rejected=await anon.request('/api/passkeys/authenticate/verify','POST',first.authentication(opts.data.options,origin,override));
  assert.equal(rejected.status,401); record(name,{status:success.status,data:success.data},rejected);
}
const wrongOriginOptions=await anon.request('/api/passkeys/authenticate/options','POST',{});
const wrongOrigin=await anon.request('/api/passkeys/authenticate/verify','POST',first.authentication(wrongOriginOptions.data.options,'https://untrusted.invalid'));
assert.equal(wrongOrigin.status,401); record('signed response with wrong origin',{status:success.status,data:success.data},wrongOrigin);
const concurrentOptions=await anon.request('/api/passkeys/authenticate/options','POST',{});
const concurrentPayload=first.authentication(concurrentOptions.data.options,origin);
const concurrentCookie=anon.cookie();
const concurrent=await Promise.all([anon.request('/api/passkeys/authenticate/verify','POST',concurrentPayload,concurrentCookie),anon.request('/api/passkeys/authenticate/verify','POST',concurrentPayload,concurrentCookie)]);
assert.deepEqual(concurrent.map(r=>r.status).sort(),[200,400]);
record('atomic challenge use under concurrent replay',concurrent.find(r=>r.status===200),concurrent.find(r=>r.status===400));
const expiryOptions=await anon.request('/api/passkeys/authenticate/options','POST',{});
assert.match(expiryOptions.data.options.challenge,/^[A-Za-z0-9_-]+$/);
localSql(`UPDATE challenges SET expires_at=0 WHERE challenge='${expiryOptions.data.options.challenge}'`);
const expired=await anon.request('/api/passkeys/authenticate/verify','POST',first.authentication(expiryOptions.data.options,origin));
assert.equal(expired.status,400); record('controlled local challenge expiry',{status:success.status,data:success.data},expired);
const foreignDeletion = await b.request(`/api/passkeys/${first.id}`,'DELETE',{confirm:true}); assert.equal(foreignDeletion.status,403);
const deleteFirst = await a.request(`/api/passkeys/${first.id}`,'DELETE',{confirm:true}); assert.equal(deleteFirst.status,200); assert.equal(deleteFirst.data.remaining,1);
assert.equal((await anon.request('/api/vault')).status,401,'Deleting the credential must revoke every session created with it.');
const savedFirst = await login(anon,first); assert.equal(savedFirst.status,401);
const keptSecond = await login(a,second); assert.equal(keptSecond.status,200);
record('deleted versus remaining credential',{status:keptSecond.status,data:keptSecond.data},{status:savedFirst.status,data:savedFirst.data});
const deleteLast = await a.request(`/api/passkeys/${second.id}`,'DELETE',{confirm:true}); assert.equal(deleteLast.status,200); assert.equal(deleteLast.data.remaining,0); assert.equal(deleteLast.data.loggedOut,true);
assert.equal((await a.request('/api/vault')).status,401);
assert.equal((await login(a,second)).status,401);
assert.equal((await a.request('/api/passkeys/register/options','POST',{username:usernameA,name:'우회 복구'})).status,409);
const beforeExpiry=await b.request('/api/vault');
const beforeExpiryCookie=b.cookie();
assert.match(accountB,/^[a-f0-9-]+$/);
localSql(`UPDATE sessions SET expires_at=0 WHERE account_id='${accountB}'`);
const afterExpiry=await b.request('/api/vault','GET',undefined,beforeExpiryCookie);
assert.equal(afterExpiry.status,401); record('controlled local session expiry',beforeExpiry,afterExpiry);
assert.equal((await login(b,other)).status,200);
await b.request(`/api/passkeys/${other.id}`,'DELETE',{confirm:true});

const output = {kind:'synthetic_real_crypto_protocol_validation_not_native_device_evidence',at:new Date().toISOString(),origin,passed:true,checks:evidence,exchanges,authenticationChallenges:{first:success.challenge,second:malformed.challenge},registrationChallenges:{first:registerA.challenge,second:registerB.challenge},publicKey:first.publicKey,registrationRequest:registerA.request,sessionValues:'Never persisted. Cookie replay performed only in process memory.',nativeDeviceEvidence:'PENDING: two genuine passkey accounts, two distinct credentials, actual storage location and user-approved deletion.'};
await mkdir(new URL('../../qa/',import.meta.url),{recursive:true});
await writeFile(new URL('../../qa/synthetic-protocol-result.json',import.meta.url),JSON.stringify(output,null,2)+'\n');
console.log(`PASS: ${evidence.length} paired protocol scenarios; native device evidence remains pending.`);
